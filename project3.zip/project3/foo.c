//Author Phillip Chae
//Description: C representation of given_foo object file

//Takes two long values and returns one long value
long foo(long a, long b){
	return(52*a + 93*b + 95*(b-a));
}
