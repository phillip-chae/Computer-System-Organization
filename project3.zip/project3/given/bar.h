
/* DO NOT MODIFY THIS FILE */ 

/* This is the signature for the function 
 * that you need to implement. 
 */ 
long bar ( long a, long b ) ; 
